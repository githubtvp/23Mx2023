console.log("Print n to 1 "); 
let n = 10; 
console.log("n = " + n); 
while( n >=1 )      
 {
  console.log(n + " ");
  n--;
 }           
 