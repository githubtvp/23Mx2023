console.log("Print all Even natural numbers from 1 to n ");
let n = 100;
console.log("n = " + n);
let x = 2;
while (x <= n) 
{
  if (x % 2 == 0) {
    console.log(x);
  }
  x+= 2;
}
