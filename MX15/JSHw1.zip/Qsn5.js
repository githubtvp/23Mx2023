console.log("Alphabets from (a-z) are:"); 
// Using for loop for (a-z):
for (i = 97; i <= 122; i++) {
    console.log(String.fromCharCode(i));
}