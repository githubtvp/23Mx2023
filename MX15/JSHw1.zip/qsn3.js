console.log("Print sum of natural numbers from 1 to n ");
let n = 10;
console.log("n = " + n);
sum = 0;
while (n >= 1) {
   sum += n;
   n--;
}
console.log(sum);
